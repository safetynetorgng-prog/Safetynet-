import {getStore} from '@netlify/blobs';
import {timingSafeEqual} from 'node:crypto';
const nk=s=>String(s||'').toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,40);
const J=(o,s=200)=>new Response(JSON.stringify(o),{status:s,headers:{'content-type':'application/json','cache-control':'no-store'}});
function authed(p){const e=process.env.ADMIN_PASSWORD||'';const a=Buffer.from(String(p||'')),b=Buffer.from(e);return a.length===b.length&&timingSafeEqual(a,b)}
export default async (req) => {
  if (req.method!=='POST') return J({error:'method'},405);
  if (!process.env.ADMIN_PASSWORD) return J({error:'ADMIN_PASSWORD is not set in Netlify'},500);
  if (!authed(req.headers.get('x-admin-password'))) return J({error:'unauthorized'},401);
  const d = await req.json().catch(()=>({})), s = getStore('ids');
  if (d.action==='save') {
    const r=d.record||{}, k=nk(r.id);
    if (!k||!r.name) return J({error:'ID and name required'},400);
    const old = await s.get(k,{type:'json'});
    await s.setJSON(k,{id:String(r.id).trim(),name:String(r.name).trim(),role:String(r.role||'').trim(),issue:r.issue||'',expiry:r.expiry||'',status:old?old.status:'active',photo:String(r.photo||'').slice(0,200000)});
  } else if (d.action==='status') {
    const k=nk(d.id), o=await s.get(k,{type:'json'});
    if (o) { o.status = d.status==='revoked'?'revoked':'active'; await s.setJSON(k,o); }
  } else if (d.action==='delete') { await s.delete(nk(d.id)); }
  const {blobs} = await s.list();
  const records = (await Promise.all(blobs.map(b=>s.get(b.key,{type:'json'})))).filter(Boolean);
  return J({records});
};
export const config = {path:'/api/admin'};

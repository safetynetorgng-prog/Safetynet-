import {getStore} from '@netlify/blobs';
const nk=s=>String(s||'').toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,40);
const H={'content-type':'application/json','cache-control':'no-store'};
export default async (req) => {
  const id = nk(new URL(req.url).searchParams.get('id'));
  if (!id) return new Response(JSON.stringify({found:false}), {headers:H});
  const r = await getStore('ids').get(id, {type:'json'});
  if (!r) return new Response(JSON.stringify({found:false}), {headers:H});
  const {id:cid,name,role,issue,expiry,status,photo} = r;
  return new Response(JSON.stringify({found:true,id:cid,name,role,issue,expiry,status,photo}), {headers:H});
};
export const config = {path:'/api/verify'};

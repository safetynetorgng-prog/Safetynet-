# Safetynet ID Verification Website

- `/`            Public page: anyone enters an ID number to verify it.
- `/admin.html`  Private: password-protected ID card generator + database.
- Database: Netlify Blobs (built in, free). IDs go live the moment you press "Save to database".

## Deploy (free, about 10 minutes)
1. Create a free GitHub account and a new repository. Upload everything in this folder (keep the folder structure).
2. On netlify.com choose Add new site > Import an existing project > GitHub > pick the repository. Leave build settings as they are and deploy.
3. In Netlify: Site configuration > Environment variables > add `ADMIN_PASSWORD` with the password you want. Then Deploys > Trigger deploy.
4. Open `https://YOUR-SITE.netlify.app/admin.html`, log in, add IDs, and download each card. The QR on every card opens your site's verification page.
5. Optional: add your own domain under Domain management.

Note: the QR code uses the address of the site you are logged in on, so open admin.html on your final address before downloading cards.
